#include "task.h"

int task_tid = 0;
int total_turnaround_time = 0;
int total_waiting_time = 0;
int total_response_time = 0;